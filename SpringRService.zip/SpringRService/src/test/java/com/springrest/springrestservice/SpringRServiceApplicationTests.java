package com.springrest.springrestservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
