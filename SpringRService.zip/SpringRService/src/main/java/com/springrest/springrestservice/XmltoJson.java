package com.springrest.springrestservice;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;



@RestController
public class XmltoJson {
	@Autowired
	private EmployeeService employeeService;
	@PostMapping(path="/dataEmployee")
			//consumes ={MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE},
		//  produces={MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})

	public String addEmployee(@RequestBody Employees employee)
	{
	XmlMapper xml = new XmlMapper();
	String value=  "<employee>\r\n"
	+"<id>"+employee.getId()+"</id>\r\n"
	+"<name>"+employee.getName()+"</name>\r\n"
	+"<age>"+employee.getAge()+"</age>\r\n"
    +"<salary>"+employee.getAge()+"</salary>\r\n"
	+"</employee>";

	try{
	JsonNode json =xml.readTree(value.getBytes());
	ObjectMapper obj =new ObjectMapper();
	String jsonOut=obj.writeValueAsString(json);
	System.out.println(jsonOut);
	
			}catch (IOException e){
	e.printStackTrace();
	}
	return"";
	}
}
