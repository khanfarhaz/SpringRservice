package com.springrest.springrestservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRServiceApplication.class, args);
	}

}
