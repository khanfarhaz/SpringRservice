package com.springrest.springrestservice;

import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JsonToXml {

	
	
	@Autowired
	private EmployeeService employeeService;
	@PostMapping(path="/employee")
	public String addCourse(@RequestBody Employees employee)
	{
		this.employeeService.addEmployee(employee);
		JSONObject jsonObj= new JSONObject(employee);
		System.out.println(XML.toString(jsonObj));
		return this.employeeService.addEmployee(employee);
	}
}
