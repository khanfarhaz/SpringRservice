package com.springrest.springrestservice;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	
	List<Employees>list;
	public EmployeeServiceImpl() {
    list = new ArrayList<>();

	}
	

	@Override
	public String addEmployee(Employees employee) {
		// TODO Auto-generated method stub
		return "";
	}

}
