package com.springrest.springrestservice;

public interface EmployeeService {

	String addEmployee(Employees employee);

	
}
